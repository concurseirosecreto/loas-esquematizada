import { Scale, BookOpen, Users, Building2 } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-r from-slate-800 to-slate-900 text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* About */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-yellow-500 p-2 rounded-lg">
                <Scale size={24} className="text-slate-800" />
              </div>
              <div>
                <h3 className="font-bold text-lg">LOAS Esquematizada</h3>
                <p className="text-slate-400 text-sm">Lei 8.742/1993</p>
              </div>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed">
              Material de estudo completo sobre a Lei Orgânica da Assistência Social, 
              com esquematização detalhada, conceituação doutrinária e exemplos práticos 
              para cada artigo. Ideal para concurseiros, estudantes de Serviço Social, 
              gestores e trabalhadores do SUAS.
            </p>
          </div>

          {/* Quick Stats */}
          <div>
            <h4 className="font-semibold mb-4 text-yellow-400">Conteúdo</h4>
            <ul className="space-y-2 text-sm text-slate-300">
              <li className="flex items-center gap-2">
                <BookOpen size={16} className="text-blue-400" />
                <span>7 Capítulos completos</span>
              </li>
              <li className="flex items-center gap-2">
                <Users size={16} className="text-green-400" />
                <span>Artigos conceituados</span>
              </li>
              <li className="flex items-center gap-2">
                <Building2 size={16} className="text-purple-400" />
                <span>Exemplos práticos</span>
              </li>
            </ul>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold mb-4 text-yellow-400">Links Úteis</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="https://www.planalto.gov.br/ccivil_03/leis/l8742.htm" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-300 hover:text-yellow-400 transition-colors"
                >
                  → Texto original da Lei
                </a>
              </li>
              <li>
                <a 
                  href="https://www.gov.br/mds/pt-br" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-300 hover:text-yellow-400 transition-colors"
                >
                  → Ministério do Desenvolvimento Social
                </a>
              </li>
              <li>
                <a 
                  href="https://www.gov.br/mds/pt-br/acoes-e-programas/assistencia-social" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-slate-300 hover:text-yellow-400 transition-colors"
                >
                  → Portal da Assistência Social
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-700 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-sm text-center md:text-left">
              Lei Orgânica da Assistência Social - Dispõe sobre a organização da Assistência Social no Brasil
            </p>
            <div className="flex items-center gap-2 text-slate-500 text-xs">
              <span>Lei nº 8.742, de 7 de dezembro de 1993</span>
              <span>•</span>
              <span>Atualizada com alterações da Lei 12.435/2011</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
