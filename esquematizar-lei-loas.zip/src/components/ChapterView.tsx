import { Chapter, Section, Article } from '../types';
import ArticleCard from './ArticleCard';

interface ChapterViewProps {
  chapter: Chapter;
  searchTerm: string;
}

function filterArticles(articles: Article[], searchTerm: string): Article[] {
  if (!searchTerm) return articles;
  
  const term = searchTerm.toLowerCase();
  return articles.filter(article => 
    article.title.toLowerCase().includes(term) ||
    article.text.toLowerCase().includes(term) ||
    article.concept.toLowerCase().includes(term) ||
    article.example.toLowerCase().includes(term) ||
    article.number.toLowerCase().includes(term)
  );
}

export default function ChapterView({ chapter, searchTerm }: ChapterViewProps) {
  return (
    <div className="space-y-8">
      {/* Chapter Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl p-6 shadow-lg">
        <div className="flex items-center gap-4">
          <span className="bg-white/20 text-white text-2xl font-bold w-14 h-14 rounded-xl flex items-center justify-center">
            {chapter.number}
          </span>
          <div>
            <p className="text-blue-200 text-sm">Capítulo {chapter.number}</p>
            <h2 className="text-2xl font-bold">{chapter.title}</h2>
          </div>
        </div>
      </div>

      {/* Sections or Articles */}
      {chapter.sections ? (
        chapter.sections.map((section: Section) => (
          <div key={section.id} className="space-y-6">
            <div className="bg-gradient-to-r from-amber-50 to-yellow-50 border-l-4 border-amber-400 p-4 rounded-r-lg">
              <h3 className="text-lg font-bold text-amber-900">{section.title}</h3>
            </div>
            
            {filterArticles(section.articles, searchTerm).map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
            
            {filterArticles(section.articles, searchTerm).length === 0 && searchTerm && (
              <div className="text-center py-8 text-gray-500">
                Nenhum artigo encontrado com "{searchTerm}" nesta seção.
              </div>
            )}
          </div>
        ))
      ) : (
        <>
          {filterArticles(chapter.articles || [], searchTerm).map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
          
          {filterArticles(chapter.articles || [], searchTerm).length === 0 && searchTerm && (
            <div className="text-center py-8 text-gray-500">
              Nenhum artigo encontrado com "{searchTerm}" neste capítulo.
            </div>
          )}
        </>
      )}
    </div>
  );
}
