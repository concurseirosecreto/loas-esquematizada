import { BookOpen, ChevronRight } from 'lucide-react';
import { Chapter } from '../types';

interface SidebarProps {
  chapters: Chapter[];
  activeChapter: string;
  setActiveChapter: (id: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export default function Sidebar({ chapters, activeChapter, setActiveChapter, sidebarOpen, setSidebarOpen }: SidebarProps) {
  const handleChapterClick = (id: string) => {
    setActiveChapter(id);
    setSidebarOpen(false);
  };

  return (
    <>
      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      <aside className={`
        fixed lg:sticky top-0 left-0 z-40
        w-80 h-screen lg:h-[calc(100vh-180px)] lg:top-[180px]
        bg-white shadow-xl lg:shadow-md
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        overflow-y-auto
      `}>
        <div className="p-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center gap-2 text-blue-900">
            <BookOpen size={20} />
            <h2 className="font-bold">Estrutura da Lei</h2>
          </div>
          <p className="text-xs text-gray-500 mt-1">Clique para navegar</p>
        </div>
        
        <nav className="p-4 space-y-2">
          {chapters.map((chapter) => (
            <button
              key={chapter.id}
              onClick={() => handleChapterClick(chapter.id)}
              className={`
                w-full text-left p-3 rounded-lg transition-all duration-200
                flex items-center gap-3 group
                ${activeChapter === chapter.id 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'hover:bg-blue-50 text-gray-700'
                }
              `}
            >
              <span className={`
                w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold
                ${activeChapter === chapter.id 
                  ? 'bg-white/20 text-white' 
                  : 'bg-blue-100 text-blue-600'
                }
              `}>
                {chapter.number}
              </span>
              <span className="flex-1 text-sm font-medium">{chapter.title}</span>
              <ChevronRight size={16} className={`
                transition-transform
                ${activeChapter === chapter.id ? 'rotate-90' : 'group-hover:translate-x-1'}
              `} />
            </button>
          ))}
        </nav>
        
        <div className="p-4 border-t bg-gray-50">
          <div className="text-xs text-gray-500 space-y-1">
            <p><strong>Lei nº 8.742</strong>, de 7 de dezembro de 1993</p>
            <p>Dispõe sobre a organização da Assistência Social e dá outras providências.</p>
            <p className="pt-2 text-blue-600">
              <a href="https://www.planalto.gov.br/ccivil_03/leis/l8742.htm" target="_blank" rel="noopener noreferrer" className="hover:underline">
                Ver texto original →
              </a>
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
