import { Scale, Menu, X, Search } from 'lucide-react';

interface HeaderProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  setSidebarOpen: (open: boolean) => void;
  sidebarOpen: boolean;
}

export default function Header({ searchTerm, setSearchTerm, setSidebarOpen, sidebarOpen }: HeaderProps) {
  return (
    <header className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            
            <div className="flex items-center gap-3">
              <div className="bg-white/10 p-2 rounded-lg">
                <Scale size={28} className="text-yellow-400" />
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-bold">Lei 8.742/1993</h1>
                <p className="text-blue-200 text-sm md:text-base">Lei Orgânica da Assistência Social - LOAS</p>
              </div>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-4">
            <div className="relative">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" />
              <input
                type="text"
                placeholder="Buscar na lei..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-2 text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-yellow-400/50 w-64"
              />
            </div>
          </div>
        </div>
        
        {/* Mobile search */}
        <div className="md:hidden mt-4">
          <div className="relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-300" />
            <input
              type="text"
              placeholder="Buscar na lei..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-2 text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-yellow-400/50"
            />
          </div>
        </div>
      </div>
      
      <div className="bg-gradient-to-r from-yellow-500 to-orange-500 py-2 px-4">
        <div className="max-w-7xl mx-auto">
          <p className="text-center text-sm font-medium text-blue-900">
            📚 Esquematização completa com conceitos e exemplos práticos de cada artigo
          </p>
        </div>
      </div>
    </header>
  );
}
