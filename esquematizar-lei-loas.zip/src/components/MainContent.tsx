import { Chapter } from '../types';
import ChapterView from './ChapterView';

interface MainContentProps {
  chapters: Chapter[];
  activeChapter: string;
  searchTerm: string;
}

export default function MainContent({ chapters, activeChapter, searchTerm }: MainContentProps) {
  const chapter = chapters.find(c => c.id === activeChapter);
  
  if (!chapter) return null;

  return (
    <main className="flex-1 p-4 lg:p-8 lg:ml-0 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <ChapterView chapter={chapter} searchTerm={searchTerm} />
      </div>
    </main>
  );
}
