import { useState } from 'react';
import { Article, Paragraph, Item } from '../types';
import { BookOpen, Lightbulb, FileText, ChevronDown, ChevronUp, ListOrdered, Hash } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
}

function ItemView({ item, level = 0 }: { item: Item; level?: number }) {
  const [expanded, setExpanded] = useState(false);
  const hasDetails = item.concept || item.example;
  
  return (
    <div className={`${level > 0 ? 'ml-6' : ''}`}>
      <div 
        className={`flex gap-3 p-3 rounded-lg ${hasDetails ? 'cursor-pointer hover:bg-gray-50' : ''} transition-colors`}
        onClick={() => hasDetails && setExpanded(!expanded)}
      >
        <span className="bg-blue-100 text-blue-700 font-bold text-sm w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0">
          {item.letter}
        </span>
        <div className="flex-1">
          <p className="text-gray-700">{item.text}</p>
          {hasDetails && (
            <button className="text-blue-500 text-sm mt-1 flex items-center gap-1">
              {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              {expanded ? 'Ocultar detalhes' : 'Ver conceito e exemplo'}
            </button>
          )}
        </div>
      </div>
      
      {expanded && hasDetails && (
        <div className="ml-10 mt-2 space-y-3">
          {item.concept && (
            <div className="bg-purple-50 border-l-4 border-purple-400 p-3 rounded-r-lg">
              <div className="flex items-center gap-2 text-purple-700 font-semibold text-sm mb-1">
                <Lightbulb size={14} />
                <span>Conceito</span>
              </div>
              <p className="text-purple-900 text-sm">{item.concept}</p>
            </div>
          )}
          {item.example && (
            <div className="bg-green-50 border-l-4 border-green-400 p-3 rounded-r-lg">
              <div className="flex items-center gap-2 text-green-700 font-semibold text-sm mb-1">
                <FileText size={14} />
                <span>Exemplo Prático</span>
              </div>
              <p className="text-green-900 text-sm">{item.example}</p>
            </div>
          )}
        </div>
      )}
      
      {item.subItems && (
        <div className="ml-6 mt-2 space-y-1 border-l-2 border-gray-200 pl-4">
          {item.subItems.map((subItem) => (
            <div key={subItem.id} className="flex gap-2 py-1">
              <span className="text-gray-500 font-medium text-sm">{subItem.letter})</span>
              <p className="text-gray-600 text-sm">{subItem.text}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ParagraphView({ paragraph }: { paragraph: Paragraph }) {
  const [expanded, setExpanded] = useState(false);
  const hasDetails = paragraph.concept || paragraph.example;
  
  return (
    <div className="border-l-4 border-indigo-300 pl-4 py-2">
      <div 
        className={`${hasDetails ? 'cursor-pointer' : ''}`}
        onClick={() => hasDetails && setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2 text-indigo-700 font-semibold text-sm">
          <Hash size={14} />
          <span>{paragraph.number}</span>
        </div>
        <p className="text-gray-700 mt-1">{paragraph.text}</p>
        {hasDetails && (
          <button className="text-indigo-500 text-sm mt-2 flex items-center gap-1">
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            {expanded ? 'Ocultar' : 'Ver conceito e exemplo'}
          </button>
        )}
      </div>
      
      {expanded && hasDetails && (
        <div className="mt-3 space-y-3">
          {paragraph.concept && (
            <div className="bg-purple-50 border-l-4 border-purple-400 p-3 rounded-r-lg">
              <div className="flex items-center gap-2 text-purple-700 font-semibold text-sm mb-1">
                <Lightbulb size={14} />
                <span>Conceito</span>
              </div>
              <p className="text-purple-900 text-sm">{paragraph.concept}</p>
            </div>
          )}
          {paragraph.example && (
            <div className="bg-green-50 border-l-4 border-green-400 p-3 rounded-r-lg">
              <div className="flex items-center gap-2 text-green-700 font-semibold text-sm mb-1">
                <FileText size={14} />
                <span>Exemplo Prático</span>
              </div>
              <p className="text-green-900 text-sm">{paragraph.example}</p>
            </div>
          )}
        </div>
      )}
      
      {paragraph.items && (
        <div className="mt-3 space-y-2">
          {paragraph.items.map((item) => (
            <ItemView key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function ArticleCard({ article }: ArticleCardProps) {
  const [showConcept, setShowConcept] = useState(true);
  const [showExample, setShowExample] = useState(true);
  
  return (
    <article className="bg-white rounded-2xl shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow">
      {/* Article Header */}
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 text-white p-4">
        <div className="flex items-center gap-3">
          <span className="bg-yellow-400 text-slate-800 font-bold px-3 py-1 rounded-lg text-sm">
            Art. {article.number}
          </span>
          <h3 className="font-semibold">{article.title}</h3>
          {article.isRevoked && (
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded">REVOGADO</span>
          )}
          {article.updatedBy && (
            <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded">Alterado</span>
          )}
        </div>
      </div>
      
      {/* Article Content */}
      <div className="p-5 space-y-4">
        {/* Original Text */}
        <div className="bg-slate-50 rounded-xl p-4">
          <div className="flex items-center gap-2 text-slate-600 font-semibold text-sm mb-2">
            <BookOpen size={16} />
            <span>Texto Legal</span>
          </div>
          <p className="text-gray-800 leading-relaxed">{article.text}</p>
        </div>
        
        {/* Items */}
        {article.items && article.items.length > 0 && (
          <div className="space-y-2 bg-gray-50 rounded-xl p-4">
            <div className="flex items-center gap-2 text-gray-600 font-semibold text-sm mb-3">
              <ListOrdered size={16} />
              <span>Incisos</span>
            </div>
            {article.items.map((item) => (
              <ItemView key={item.id} item={item} />
            ))}
          </div>
        )}
        
        {/* Concept */}
        <div className="bg-purple-50 rounded-xl overflow-hidden">
          <button 
            onClick={() => setShowConcept(!showConcept)}
            className="w-full flex items-center justify-between p-4 text-purple-700 font-semibold hover:bg-purple-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Lightbulb size={18} />
              <span>💡 Conceituação Doutrinária</span>
            </div>
            {showConcept ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </button>
          {showConcept && (
            <div className="px-4 pb-4">
              <p className="text-purple-900 leading-relaxed">{article.concept}</p>
            </div>
          )}
        </div>
        
        {/* Example */}
        <div className="bg-green-50 rounded-xl overflow-hidden">
          <button 
            onClick={() => setShowExample(!showExample)}
            className="w-full flex items-center justify-between p-4 text-green-700 font-semibold hover:bg-green-100 transition-colors"
          >
            <div className="flex items-center gap-2">
              <FileText size={18} />
              <span>📋 Exemplo Prático</span>
            </div>
            {showExample ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </button>
          {showExample && (
            <div className="px-4 pb-4">
              <p className="text-green-900 leading-relaxed">{article.example}</p>
            </div>
          )}
        </div>
        
        {/* Paragraphs */}
        {article.paragraphs && article.paragraphs.length > 0 && (
          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-semibold text-gray-700 flex items-center gap-2">
              <Hash size={16} />
              Parágrafos
            </h4>
            {article.paragraphs.map((paragraph) => (
              <ParagraphView key={paragraph.id} paragraph={paragraph} />
            ))}
          </div>
        )}
      </div>
    </article>
  );
}
