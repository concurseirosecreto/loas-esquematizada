import { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import Footer from './components/Footer';
import { chapters } from './data/lawData';

function App() {
  const [activeChapter, setActiveChapter] = useState<string>('cap1');
  const [searchTerm, setSearchTerm] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex flex-col">
      <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} setSidebarOpen={setSidebarOpen} sidebarOpen={sidebarOpen} />
      
      <div className="flex flex-1">
        <Sidebar 
          chapters={chapters} 
          activeChapter={activeChapter} 
          setActiveChapter={setActiveChapter}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
        
        <MainContent 
          chapters={chapters} 
          activeChapter={activeChapter} 
          searchTerm={searchTerm}
        />
      </div>
      
      <Footer />
    </div>
  );
}

export default App;
