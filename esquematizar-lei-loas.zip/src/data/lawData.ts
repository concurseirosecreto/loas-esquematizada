import { Chapter } from '../types';

export const chapters: Chapter[] = [
  {
    id: 'cap1',
    number: 'I',
    title: 'Das Definições e dos Objetivos',
    articles: [
      {
        id: 'art1',
        number: '1º',
        title: 'Definição de Assistência Social',
        text: 'A assistência social, direito do cidadão e dever do Estado, é Política de Seguridade Social não contributiva, que provê os mínimos sociais, realizada através de um conjunto integrado de ações de iniciativa pública e da sociedade, para garantir o atendimento às necessidades básicas.',
        concept: 'Este artigo estabelece a NATUREZA JURÍDICA da assistência social no Brasil. Trata-se de um DIREITO FUNDAMENTAL SOCIAL (art. 6º, CF/88) e um DEVER DO ESTADO. A assistência social integra o tripé da Seguridade Social (junto com Saúde e Previdência), mas diferencia-se por ser NÃO CONTRIBUTIVA - ou seja, não exige contribuição prévia do beneficiário. O conceito de "mínimos sociais" refere-se ao patamar mínimo de dignidade que deve ser garantido a todo cidadão.',
        example: 'EXEMPLO PRÁTICO: Maria, desempregada e sem renda, pode acessar o Benefício de Prestação Continuada (BPC) ou ser incluída em programas de transferência de renda sem nunca ter contribuído para a Previdência Social. Isso porque a assistência social é não contributiva - basta comprovar a situação de vulnerabilidade. Diferentemente da aposentadoria (previdência), que exige contribuições prévias, a assistência social atende quem precisa, independentemente de contribuição.',
      },
      {
        id: 'art2',
        number: '2º',
        title: 'Objetivos da Assistência Social',
        text: 'A assistência social tem por objetivos:',
        concept: 'Este artigo elenca os TRÊS GRANDES OBJETIVOS da política de assistência social, reformulados pela Lei 12.435/2011: (1) PROTEÇÃO SOCIAL - garantia da vida e redução de danos; (2) VIGILÂNCIA SOCIOASSISTENCIAL - análise territorial das vulnerabilidades; (3) DEFESA DE DIREITOS - garantia de acesso às provisões. Esses objetivos orientam toda a estruturação do SUAS.',
        example: 'EXEMPLO PRÁTICO: O CRAS de um município identifica, através da vigilância socioassistencial, que determinado bairro possui alto índice de trabalho infantil. A partir disso, implementa ações de proteção social (acompanhamento das famílias, inserção em programas) e defesa de direitos (articulação com Conselho Tutelar e Ministério Público).',
        items: [
          {
            id: 'art2-i',
            letter: 'I',
            text: 'a proteção social, que visa à garantia da vida, à redução de danos e à prevenção da incidência de riscos, especialmente:',
            concept: 'A PROTEÇÃO SOCIAL é o núcleo central da assistência social. Divide-se em: proteção à família, maternidade, infância, adolescência e velhice; amparo às crianças e adolescentes carentes; promoção da integração ao mercado de trabalho; habilitação e reabilitação de pessoas com deficiência; garantia de 1 salário mínimo mensal (BPC).',
            example: 'EXEMPLO: João, 70 anos, sem família e sem renda, recebe o BPC de um salário mínimo mensal, garantindo sua sobrevivência digna.',
            subItems: [
              { id: 'art2-i-a', letter: 'a', text: 'a proteção à família, à maternidade, à infância, à adolescência e à velhice' },
              { id: 'art2-i-b', letter: 'b', text: 'o amparo às crianças e aos adolescentes carentes' },
              { id: 'art2-i-c', letter: 'c', text: 'a promoção da integração ao mercado de trabalho' },
              { id: 'art2-i-d', letter: 'd', text: 'a habilitação e reabilitação das pessoas com deficiência e a promoção de sua integração à vida comunitária' },
              { id: 'art2-i-e', letter: 'e', text: 'a garantia de 1 (um) salário-mínimo de benefício mensal à pessoa com deficiência e ao idoso que comprovem não possuir meios de prover a própria manutenção ou de tê-la provida por sua família' },
            ]
          },
          {
            id: 'art2-ii',
            letter: 'II',
            text: 'a vigilância socioassistencial, que visa a analisar territorialmente a capacidade protetiva das famílias e nela a ocorrência de vulnerabilidades, de ameaças, de vitimizações e danos',
            concept: 'A VIGILÂNCIA SOCIOASSISTENCIAL é uma função da política de assistência social que produz, sistematiza e analisa informações territorializadas sobre as situações de vulnerabilidade e risco que incidem sobre famílias e indivíduos. Funciona como um "radar social" do território.',
            example: 'EXEMPLO: A equipe do CRAS realiza mapeamento do território e identifica que 40% das famílias atendidas vivem em situação de insegurança alimentar. Com base nesses dados, o município planeja ações específicas de combate à fome naquela região.',
          },
          {
            id: 'art2-iii',
            letter: 'III',
            text: 'a defesa de direitos, que visa a garantir o pleno acesso aos direitos no conjunto das provisões socioassistenciais',
            concept: 'A DEFESA DE DIREITOS é o terceiro objetivo da assistência social, que busca garantir que os cidadãos acessem efetivamente os benefícios, serviços, programas e projetos a que têm direito. Inclui ações de orientação, informação e encaminhamento.',
            example: 'EXEMPLO: Um assistente social do CRAS identifica que uma família tem direito ao BPC, mas desconhece o benefício. O profissional orienta sobre os requisitos, auxilia na reunião de documentos e encaminha o requerimento ao INSS.',
          }
        ],
        paragraphs: [
          {
            id: 'art2-pu',
            number: 'Parágrafo único',
            text: 'Para o enfrentamento da pobreza, a assistência social realiza-se de forma integrada às políticas setoriais, garantindo mínimos sociais e provimento de condições para atender contingências sociais e promovendo a universalização dos direitos sociais.',
            concept: 'Este parágrafo estabelece o princípio da INTERSETORIALIDADE - a assistência social não atua isoladamente, mas em articulação com outras políticas (saúde, educação, habitação, trabalho). O enfrentamento da pobreza exige ação coordenada de múltiplas políticas públicas.',
            example: 'EXEMPLO: Uma família em extrema pobreza é atendida pelo CRAS, que articula: inscrição no CadÚnico (assistência), matrícula escolar das crianças (educação), atendimento na UBS (saúde) e inscrição em curso profissionalizante (trabalho). Essa é a intersetorialidade na prática.',
          }
        ]
      },
      {
        id: 'art3',
        number: '3º',
        title: 'Entidades e Organizações de Assistência Social',
        text: 'Consideram-se entidades e organizações de assistência social aquelas sem fins lucrativos que, isolada ou cumulativamente, prestam atendimento e assessoramento aos beneficiários abrangidos por esta Lei, bem como as que atuam na defesa e garantia de direitos.',
        concept: 'Este artigo define o conceito legal de ENTIDADE DE ASSISTÊNCIA SOCIAL. São requisitos: (1) ausência de fins lucrativos; (2) atuação em pelo menos uma das três modalidades: ATENDIMENTO, ASSESSORAMENTO ou DEFESA E GARANTIA DE DIREITOS. As entidades integram a rede socioassistencial do SUAS e podem receber recursos públicos mediante convênios.',
        example: 'EXEMPLO: A APAE (Associação de Pais e Amigos dos Excepcionais) é uma entidade de ATENDIMENTO - presta serviços diretamente às pessoas com deficiência. Já uma associação de moradores que promove cursos de liderança comunitária é de ASSESSORAMENTO. Uma ONG que atua em processos judiciais de defesa de direitos de crianças é de DEFESA E GARANTIA DE DIREITOS.',
        paragraphs: [
          {
            id: 'art3-p1',
            number: '§ 1º',
            text: 'São de atendimento aquelas entidades que, de forma continuada, permanente e planejada, prestam serviços, executam programas ou projetos e concedem benefícios de prestação social básica ou especial, dirigidos às famílias e indivíduos em situações de vulnerabilidade ou risco social e pessoal.',
            concept: 'ENTIDADES DE ATENDIMENTO são aquelas que prestam serviços diretos à população. Características: continuidade, permanência e planejamento. Podem ofertar proteção social básica (prevenção) ou especial (situações de violação de direitos).',
            example: 'EXEMPLO: Um abrigo institucional para crianças e adolescentes afastados do convívio familiar é uma entidade de atendimento de proteção social especial de alta complexidade.',
          },
          {
            id: 'art3-p2',
            number: '§ 2º',
            text: 'São de assessoramento aquelas que, de forma continuada, permanente e planejada, prestam serviços e executam programas ou projetos voltados prioritariamente para o fortalecimento dos movimentos sociais e das organizações de usuários, formação e capacitação de lideranças.',
            concept: 'ENTIDADES DE ASSESSORAMENTO não prestam serviços diretos, mas fortalecem a capacidade de organização e participação da comunidade. Atuam na formação política e capacitação de lideranças.',
            example: 'EXEMPLO: Uma ONG que oferece cursos de formação para líderes comunitários, ensinando sobre direitos sociais, participação em conselhos e mobilização social.',
          },
          {
            id: 'art3-p3',
            number: '§ 3º',
            text: 'São de defesa e garantia de direitos aquelas que, de forma continuada, permanente e planejada, prestam serviços e executam programas e projetos voltados prioritariamente para a defesa e efetivação dos direitos socioassistenciais, construção de novos direitos, promoção da cidadania.',
            concept: 'ENTIDADES DE DEFESA E GARANTIA DE DIREITOS atuam na advocacy (defesa de direitos), propondo políticas públicas, monitorando sua implementação e atuando na defesa jurídica dos direitos socioassistenciais.',
            example: 'EXEMPLO: Uma ONG que move ações civis públicas para garantir a implementação de serviços de acolhimento para população em situação de rua em determinado município.',
          }
        ]
      }
    ]
  },
  {
    id: 'cap2',
    number: 'II',
    title: 'Dos Princípios e das Diretrizes',
    sections: [
      {
        id: 'sec1',
        title: 'Seção I - Dos Princípios',
        articles: [
          {
            id: 'art4',
            number: '4º',
            title: 'Princípios da Assistência Social',
            text: 'A assistência social rege-se pelos seguintes princípios:',
            concept: 'Os PRINCÍPIOS são valores fundamentais que orientam toda a política de assistência social. São cinco princípios que devem guiar a formulação, implementação e avaliação de todas as ações socioassistenciais. Funcionam como bússola ética e normativa do SUAS.',
            example: 'EXEMPLO GERAL: Ao implementar um novo serviço de acolhimento, o gestor deve verificar se ele atende a todos os cinco princípios: prioriza necessidades sociais (I), universaliza direitos (II), respeita a dignidade (III), garante igualdade de acesso (IV) e é amplamente divulgado (V).',
            items: [
              {
                id: 'art4-i',
                letter: 'I',
                text: 'supremacia do atendimento às necessidades sociais sobre as exigências de rentabilidade econômica',
                concept: 'Princípio da SUPREMACIA DO SOCIAL: as decisões na assistência social devem priorizar o atendimento às necessidades da população, e não critérios de eficiência econômica ou lucro. O ser humano vem antes do capital.',
                example: 'EXEMPLO: Um município não pode fechar um CRAS em bairro vulnerável alegando apenas que é "caro demais" manter o serviço. A necessidade social prevalece sobre a rentabilidade.',
              },
              {
                id: 'art4-ii',
                letter: 'II',
                text: 'universalização dos direitos sociais, a fim de tornar o destinatário da ação assistencial alcançável pelas demais políticas públicas',
                concept: 'Princípio da UNIVERSALIZAÇÃO: a assistência social deve ser porta de entrada para o acesso a outras políticas públicas, promovendo a inclusão social integral do cidadão.',
                example: 'EXEMPLO: O CRAS, ao atender uma família, não apenas concede benefícios, mas também encaminha para saúde, educação e habitação, universalizando o acesso a direitos.',
              },
              {
                id: 'art4-iii',
                letter: 'III',
                text: 'respeito à dignidade do cidadão, à sua autonomia e ao seu direito a benefícios e serviços de qualidade, bem como à convivência familiar e comunitária, vedando-se qualquer comprovação vexatória de necessidade',
                concept: 'Princípio da DIGNIDADE: proíbe tratamentos humilhantes ou constrangedores. O usuário não pode ser submetido a situações vexatórias para comprovar sua condição de pobreza. A autonomia e a qualidade dos serviços são direitos.',
                example: 'EXEMPLO: É VEDADO exigir que uma pessoa vá ao CRAS vestida de forma "pobre" para provar que precisa de benefícios, ou que exponha publicamente sua situação de miséria. Isso é comprovação vexatória, proibida por este princípio.',
              },
              {
                id: 'art4-iv',
                letter: 'IV',
                text: 'igualdade de direitos no acesso ao atendimento, sem discriminação de qualquer natureza, garantindo-se equivalência às populações urbanas e rurais',
                concept: 'Princípio da IGUALDADE E NÃO DISCRIMINAÇÃO: todos têm igual direito de acesso, independentemente de raça, cor, religião, origem, gênero ou localização. A população rural deve ter acesso equivalente à urbana.',
                example: 'EXEMPLO: Um CRAS itinerante que atende comunidades rurais e quilombolas, garantindo que essas populações tenham o mesmo acesso a serviços que os moradores da área urbana.',
              },
              {
                id: 'art4-v',
                letter: 'V',
                text: 'divulgação ampla dos benefícios, serviços, programas e projetos assistenciais, bem como dos recursos oferecidos pelo Poder Público e dos critérios para sua concessão',
                concept: 'Princípio da PUBLICIDADE E TRANSPARÊNCIA: a população tem direito à informação clara sobre todos os benefícios e serviços disponíveis, seus critérios de acesso e forma de requerimento.',
                example: 'EXEMPLO: O município deve manter cartazes nos CRAS, site atualizado e fazer campanhas informando sobre BPC, Bolsa Família/Auxílio Brasil, serviços de convivência, etc., com linguagem acessível.',
              }
            ]
          }
        ]
      },
      {
        id: 'sec2',
        title: 'Seção II - Das Diretrizes',
        articles: [
          {
            id: 'art5',
            number: '5º',
            title: 'Diretrizes da Assistência Social',
            text: 'A organização da assistência social tem como base as seguintes diretrizes:',
            concept: 'As DIRETRIZES são orientações estratégicas para a organização e gestão da política de assistência social. Enquanto os princípios são valores, as diretrizes são linhas de ação que estruturam o funcionamento do SUAS.',
            example: 'EXEMPLO: A estruturação do SUAS em todo o Brasil segue estas três diretrizes: é descentralizado (cada ente tem suas responsabilidades), participativo (conselhos com sociedade civil) e o Estado é o principal responsável.',
            items: [
              {
                id: 'art5-i',
                letter: 'I',
                text: 'descentralização político-administrativa para os Estados, o Distrito Federal e os Municípios, e comando único das ações em cada esfera de governo',
                concept: 'Diretriz da DESCENTRALIZAÇÃO: a política de assistência social é executada de forma compartilhada entre União, Estados, DF e Municípios. Cada ente tem autonomia e responsabilidades próprias. O "comando único" significa que em cada esfera há apenas um órgão gestor responsável pela política.',
                example: 'EXEMPLO: No município, a Secretaria de Assistência Social é o "comando único" - ela coordena toda a política local. O Estado tem sua Secretaria Estadual, e a União tem o Ministério. Não pode haver dois órgãos disputando a gestão.',
              },
              {
                id: 'art5-ii',
                letter: 'II',
                text: 'participação da população, por meio de organizações representativas, na formulação das políticas e no controle das ações em todos os níveis',
                concept: 'Diretriz da PARTICIPAÇÃO POPULAR: a sociedade civil participa ativamente da política de assistência social através dos Conselhos (CNAS, CEAS, CMAS) e Conferências. É a materialização da democracia participativa.',
                example: 'EXEMPLO: O Conselho Municipal de Assistência Social (CMAS), composto por 50% de representantes do governo e 50% da sociedade civil, aprova o Plano Municipal de Assistência Social e fiscaliza sua execução.',
              },
              {
                id: 'art5-iii',
                letter: 'III',
                text: 'primazia da responsabilidade do Estado na condução da política de assistência social em cada esfera de governo',
                concept: 'Diretriz da PRIMAZIA ESTATAL: embora entidades privadas possam atuar na assistência social, o ESTADO é o principal responsável. Cabe ao poder público coordenar, financiar, regular e fiscalizar a política. A assistência social não é caridade privada, é dever do Estado.',
                example: 'EXEMPLO: Mesmo que uma ONG execute um serviço de acolhimento mediante convênio, a responsabilidade pela existência e qualidade do serviço é do Estado. Se a ONG fechar, o município deve garantir a continuidade do atendimento.',
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'cap3',
    number: 'III',
    title: 'Da Organização e da Gestão',
    articles: [
      {
        id: 'art6',
        number: '6º',
        title: 'Sistema Único de Assistência Social (SUAS)',
        text: 'A gestão das ações na área de assistência social fica organizada sob a forma de sistema descentralizado e participativo, denominado Sistema Único de Assistência Social (Suas), com os seguintes objetivos:',
        concept: 'O SUAS é o sistema público que organiza a política de assistência social no Brasil. Criado em 2005 e institucionalizado pela Lei 12.435/2011, funciona de forma semelhante ao SUS na saúde. É descentralizado (opera nos três níveis de governo), participativo (com controle social) e tem gestão compartilhada entre os entes federados.',
        example: 'EXEMPLO: Assim como você vai ao posto de saúde (SUS) quando precisa de atendimento médico, você vai ao CRAS (SUAS) quando precisa de atendimento socioassistencial. Ambos são sistemas públicos, universais e descentralizados.',
        items: [
          {
            id: 'art6-i',
            letter: 'I',
            text: 'consolidar a gestão compartilhada, o cofinanciamento e a cooperação técnica entre os entes federativos',
            concept: 'A gestão do SUAS é COMPARTILHADA: União, Estados e Municípios dividem responsabilidades, financiamento e cooperam tecnicamente. Nenhum ente atua sozinho.',
            example: 'EXEMPLO: A União financia o BPC e parte dos serviços; o Estado cofinancia e apoia tecnicamente os municípios; os municípios executam os serviços no território. Todos contribuem.',
          },
          {
            id: 'art6-ii',
            letter: 'II',
            text: 'integrar a rede pública e privada de serviços, programas, projetos e benefícios de assistência social',
            concept: 'A REDE SOCIOASSISTENCIAL integra tanto equipamentos públicos (CRAS, CREAS) quanto entidades privadas sem fins lucrativos. Todos atuam de forma complementar e integrada.',
            example: 'EXEMPLO: O CRAS (público) encaminha uma criança para serviço de convivência executado por uma ONG (privada). Ambos fazem parte da mesma rede do SUAS.',
          },
          {
            id: 'art6-iii',
            letter: 'III',
            text: 'estabelecer as responsabilidades dos entes federativos na organização, regulação, manutenção e expansão das ações',
            concept: 'Cada ente federativo tem RESPONSABILIDADES DEFINIDAS: a União normatiza e cofinancia; os Estados coordenam regionalmente e cofinanciam; os Municípios executam os serviços.',
            example: 'EXEMPLO: A União define que todo município deve ter CRAS; o Estado apoia a implantação; o município opera o equipamento no dia a dia.',
          },
          {
            id: 'art6-iv',
            letter: 'IV',
            text: 'definir os níveis de gestão, respeitadas as diversidades regionais e municipais',
            concept: 'Os NÍVEIS DE GESTÃO (inicial, básica, plena) classificam os municípios conforme sua capacidade de gestão, permitindo responsabilidades graduais.',
            example: 'EXEMPLO: Um município pequeno pode estar em gestão inicial, com menos responsabilidades e mais apoio do Estado. Um município grande em gestão plena assume mais autonomia.',
          },
          {
            id: 'art6-v',
            letter: 'V',
            text: 'implementar a gestão do trabalho e a educação permanente na assistência social',
            concept: 'A GESTÃO DO TRABALHO envolve a valorização dos profissionais do SUAS, com planos de carreira, capacitação permanente e condições adequadas de trabalho.',
            example: 'EXEMPLO: O município oferece cursos de capacitação contínua para os assistentes sociais e psicólogos do CRAS, atualizando-os sobre normativas e metodologias.',
          },
          {
            id: 'art6-vi',
            letter: 'VI',
            text: 'estabelecer a gestão integrada de serviços e benefícios',
            concept: 'GESTÃO INTEGRADA significa que serviços (atendimentos) e benefícios (transferência de renda) devem funcionar de forma articulada, potencializando seus efeitos.',
            example: 'EXEMPLO: Uma família que recebe o Bolsa Família deve também ser acompanhada pelo PAIF no CRAS. O benefício monetário vem acompanhado do serviço de acompanhamento familiar.',
          },
          {
            id: 'art6-vii',
            letter: 'VII',
            text: 'afiançar a vigilância socioassistencial e a garantia de direitos',
            concept: 'O SUAS deve manter sistemas de VIGILÂNCIA SOCIOASSISTENCIAL para monitorar vulnerabilidades no território e garantir que os direitos sejam efetivados.',
            example: 'EXEMPLO: O município mantém um sistema de informação que mapeia todas as famílias em situação de vulnerabilidade, permitindo planejar ações preventivas.',
          }
        ],
        paragraphs: [
          {
            id: 'art6-p1',
            number: '§ 1º',
            text: 'As ações ofertadas no âmbito do Suas têm por objetivo a proteção à família, à maternidade, à infância, à adolescência e à velhice e, como base de organização, o território.',
            concept: 'O SUAS é organizado com base no TERRITÓRIO - cada CRAS/CREAS é referência para uma área geográfica específica, onde conhece as famílias e suas necessidades.',
            example: 'EXEMPLO: O CRAS Centro atende as famílias do bairro Centro e adjacências; o CRAS Norte atende a região norte do município. Cada um conhece a realidade de seu território.',
          },
          {
            id: 'art6-p2',
            number: '§ 2º',
            text: 'O Suas é integrado pelos entes federativos, pelos respectivos conselhos de assistência social e pelas entidades e organizações de assistência social abrangidas por esta Lei.',
            concept: 'A COMPOSIÇÃO DO SUAS inclui: (1) entes federativos (União, Estados, DF, Municípios); (2) Conselhos de Assistência Social (CNAS, CEAS, CMAS); (3) entidades privadas de assistência social.',
            example: 'EXEMPLO: O SUAS de um município é composto pela Secretaria de Assistência Social (ente), pelo CMAS (conselho) e pelas ONGs conveniadas (entidades).',
          },
          {
            id: 'art6-p3',
            number: '§ 3º',
            text: 'A instância coordenadora da Política Nacional de Assistência Social é o Ministério do Desenvolvimento Social e Combate à Fome.',
            concept: 'O ÓRGÃO GESTOR FEDERAL da assistência social, responsável pela coordenação nacional da política. (Obs: atualmente as competências estão no Ministério do Desenvolvimento e Assistência Social, Família e Combate à Fome).',
            example: 'EXEMPLO: É o ministério federal que define as normas nacionais do SUAS, repassa recursos aos estados e municípios e coordena programas como o Bolsa Família.',
          }
        ]
      },
      {
        id: 'art6a',
        number: '6º-A',
        title: 'Tipos de Proteção Social',
        text: 'A assistência social organiza-se pelos seguintes tipos de proteção:',
        concept: 'A PROTEÇÃO SOCIAL no SUAS divide-se em dois níveis, conforme a complexidade das situações atendidas: PROTEÇÃO SOCIAL BÁSICA (prevenção) e PROTEÇÃO SOCIAL ESPECIAL (situações de violação de direitos). Esta organização permite ofertar respostas adequadas a cada nível de vulnerabilidade.',
        example: 'EXEMPLO: Uma família em situação de pobreza, mas com vínculos preservados, é atendida na Proteção Básica (CRAS). Se houver violência doméstica, passa para a Proteção Especial (CREAS).',
        items: [
          {
            id: 'art6a-i',
            letter: 'I',
            text: 'proteção social básica: conjunto de serviços, programas, projetos e benefícios da assistência social que visa a prevenir situações de vulnerabilidade e risco social por meio do desenvolvimento de potencialidades e aquisições e do fortalecimento de vínculos familiares e comunitários',
            concept: 'A PROTEÇÃO SOCIAL BÁSICA tem caráter PREVENTIVO. Atua antes que as situações de risco se instalem ou se agravem. Fortalece vínculos e desenvolve capacidades. É executada principalmente pelo CRAS.',
            example: 'EXEMPLO: Serviço de Convivência e Fortalecimento de Vínculos para idosos - previne o isolamento social, fortalece vínculos comunitários e desenvolve habilidades, antes que situações de abandono ou depressão se instalem.',
          },
          {
            id: 'art6a-ii',
            letter: 'II',
            text: 'proteção social especial: conjunto de serviços, programas e projetos que tem por objetivo contribuir para a reconstrução de vínculos familiares e comunitários, a defesa de direito, o fortalecimento das potencialidades e aquisições e a proteção de famílias e indivíduos para o enfrentamento das situações de violação de direitos',
            concept: 'A PROTEÇÃO SOCIAL ESPECIAL atende situações em que DIREITOS JÁ FORAM VIOLADOS: violência, abuso, abandono, trabalho infantil, situação de rua, etc. Divide-se em média complexidade (vínculos fragilizados) e alta complexidade (vínculos rompidos). É executada pelo CREAS e serviços de acolhimento.',
            example: 'EXEMPLO: Criança vítima de violência sexual é atendida pelo CREAS (média complexidade). Se precisar ser afastada da família, vai para abrigo institucional (alta complexidade).',
          }
        ],
        paragraphs: [
          {
            id: 'art6a-pu',
            number: 'Parágrafo único',
            text: 'A vigilância socioassistencial é um dos instrumentos das proteções da assistência social que identifica e previne as situações de risco e vulnerabilidade social e seus agravos no território.',
            concept: 'A VIGILÂNCIA SOCIOASSISTENCIAL perpassa ambos os níveis de proteção, funcionando como instrumento de identificação e monitoramento das situações de vulnerabilidade no território.',
            example: 'EXEMPLO: A vigilância socioassistencial identifica que determinada região tem alto índice de violência contra idosos, orientando a intensificação de ações preventivas (básica) e de atendimento (especial) naquele território.',
          }
        ]
      },
      {
        id: 'art6b',
        number: '6º-B',
        title: 'Rede Socioassistencial',
        text: 'As proteções sociais, básica e especial, serão ofertadas pela rede socioassistencial, de forma integrada, diretamente pelos entes públicos e/ou pelas entidades e organizações de assistência social vinculadas ao Suas, respeitadas as especificidades de cada ação.',
        concept: 'A REDE SOCIOASSISTENCIAL é o conjunto articulado de serviços públicos e privados que ofertam as proteções sociais. A vinculação ao SUAS é requisito para que entidades privadas integrem a rede e recebam recursos públicos.',
        example: 'EXEMPLO: Em um município, a rede socioassistencial pode ser composta por: 3 CRAS públicos, 1 CREAS público, 1 abrigo para idosos gerido por ONG conveniada, 2 serviços de convivência executados por entidades religiosas. Todos integram a mesma rede.',
        paragraphs: [
          {
            id: 'art6b-p1',
            number: '§ 1º',
            text: 'A vinculação ao Suas é o reconhecimento pelo Ministério do Desenvolvimento Social e Combate à Fome de que a entidade de assistência social integra a rede socioassistencial.',
            concept: 'A VINCULAÇÃO AO SUAS é o ato formal que reconhece uma entidade privada como integrante da rede. É diferente da certificação (CEBAS) e da inscrição no conselho.',
            example: 'EXEMPLO: Uma ONG que atende pessoas com deficiência solicita vinculação ao SUAS para poder firmar convênio com a prefeitura e receber recursos para execução de serviço socioassistencial.',
          },
          {
            id: 'art6b-p2',
            number: '§ 2º',
            text: 'Para o reconhecimento referido no § 1º, a entidade deverá cumprir os seguintes requisitos: I - constituir-se em conformidade com o disposto no art. 3º; II - inscrever-se em Conselho Municipal ou do Distrito Federal; III - integrar o sistema de cadastro de entidades.',
            concept: 'Os REQUISITOS PARA VINCULAÇÃO são: ser entidade de assistência social (art. 3º), estar inscrita no CMAS e integrar o cadastro nacional de entidades (CadSUAS).',
            example: 'EXEMPLO: A ONG deve primeiro obter inscrição no CMAS local, cadastrar-se no CadSUAS e demonstrar que atua em atendimento, assessoramento ou defesa de direitos.',
          }
        ]
      },
      {
        id: 'art6c',
        number: '6º-C',
        title: 'CRAS e CREAS',
        text: 'As proteções sociais, básica e especial, serão ofertadas precipuamente no Centro de Referência de Assistência Social (Cras) e no Centro de Referência Especializado de Assistência Social (Creas), respectivamente, e pelas entidades sem fins lucrativos de assistência social de que trata o art. 3º desta Lei.',
        concept: 'O CRAS e o CREAS são os principais equipamentos públicos do SUAS. O CRAS é a "porta de entrada" do sistema, ofertando proteção básica. O CREAS atende situações de média complexidade da proteção especial. São unidades públicas estatais obrigatórias.',
        example: 'EXEMPLO: Maria procura o CRAS de seu bairro para se inscrever no CadÚnico. Lá, descobre que seu filho está sofrendo bullying grave na escola. O CRAS encaminha a família para o CREAS, que oferece acompanhamento especializado.',
        paragraphs: [
          {
            id: 'art6c-p1',
            number: '§ 1º',
            text: 'O Cras é a unidade pública municipal, de base territorial, localizada em áreas com maiores índices de vulnerabilidade e risco social, destinada à articulação dos serviços socioassistenciais no seu território de abrangência e à prestação de serviços, programas e projetos socioassistenciais de proteção social básica às famílias.',
            concept: 'O CRAS - Centro de Referência de Assistência Social - é a unidade pública do SUAS responsável pela proteção social básica. Características: base territorial (atende área específica), localização em áreas vulneráveis, foco na família. Oferta o PAIF (Serviço de Proteção e Atendimento Integral à Família).',
            example: 'EXEMPLO: O CRAS Jardim das Flores está localizado no bairro mais vulnerável do município. Atende cerca de 3.000 famílias da região, oferecendo: acolhida, acompanhamento familiar (PAIF), grupos de convivência, encaminhamentos, acesso a benefícios.',
          },
          {
            id: 'art6c-p2',
            number: '§ 2º',
            text: 'O Creas é a unidade pública de abrangência e gestão municipal, estadual ou regional, destinada à prestação de serviços a indivíduos e famílias que se encontram em situação de risco pessoal ou social, por violação de direitos ou contingência, que demandam intervenções especializadas da proteção social especial.',
            concept: 'O CREAS - Centro de Referência Especializado de Assistência Social - atende situações de MÉDIA COMPLEXIDADE: violência, abuso, exploração, trabalho infantil, cumprimento de medidas socioeducativas em meio aberto. Pode ter abrangência municipal, regional ou estadual. Oferta o PAEFI (Serviço de Proteção e Atendimento Especializado a Famílias e Indivíduos).',
            example: 'EXEMPLO: Adolescente em cumprimento de medida socioeducativa de Liberdade Assistida é acompanhado pelo CREAS. A equipe (assistente social, psicólogo, advogado) trabalha a responsabilização do ato infracional e a reinserção social.',
          },
          {
            id: 'art6c-p3',
            number: '§ 3º',
            text: 'Os Cras e os Creas são unidades públicas estatais instituídas no âmbito do Suas, que possuem interface com as demais políticas públicas e articulam, coordenam e ofertam os serviços, programas, projetos e benefícios da assistência social.',
            concept: 'CRAS e CREAS são PÚBLICOS E ESTATAIS - não podem ser terceirizados ou privatizados. Atuam de forma INTERSETORIAL, articulando-se com saúde, educação, habitação, trabalho e outras políticas.',
            example: 'EXEMPLO: O CREAS, ao atender uma mulher vítima de violência doméstica, articula com: Delegacia da Mulher (segurança), UBS (saúde), escola dos filhos (educação), abrigo se necessário (proteção especial de alta complexidade).',
          }
        ]
      },
      {
        id: 'art6d',
        number: '6º-D',
        title: 'Instalações dos CRAS e CREAS',
        text: 'As instalações dos Cras e dos Creas devem ser compatíveis com os serviços neles ofertados, com espaços para trabalhos em grupo e ambientes específicos para recepção e atendimento reservado das famílias e indivíduos, assegurada a acessibilidade às pessoas idosas e com deficiência.',
        concept: 'Este artigo estabelece os REQUISITOS DE INFRAESTRUTURA dos CRAS e CREAS: espaços adequados para grupos, salas de atendimento individual com privacidade, e ACESSIBILIDADE obrigatória. A estrutura física deve garantir dignidade no atendimento.',
        example: 'EXEMPLO: Um CRAS deve ter: recepção acolhedora, sala de atendimento individual com porta fechada (sigilo), sala para grupos de até 30 pessoas, banheiros acessíveis, rampa de acesso. Não pode funcionar em um cômodo improvisado sem privacidade.',
      },
      {
        id: 'art6e',
        number: '6º-E',
        title: 'Equipes de Referência',
        text: 'Os recursos do cofinanciamento do Suas, destinados à execução das ações continuadas de assistência social, poderão ser aplicados no pagamento dos profissionais que integrarem as equipes de referência, responsáveis pela organização e oferta daquelas ações, conforme percentual apresentado pelo Ministério do Desenvolvimento Social e Combate à Fome e aprovado pelo CNAS.',
        concept: 'As EQUIPES DE REFERÊNCIA são os profissionais responsáveis pela oferta dos serviços socioassistenciais. Os recursos federais do cofinanciamento podem ser usados para pagar esses profissionais, respeitando percentual definido nacionalmente. Isso visa garantir equipes qualificadas em todo o país.',
        example: 'EXEMPLO: Um CRAS de pequeno porte deve ter equipe mínima de: 1 coordenador (nível superior), 2 técnicos de nível superior (assistente social e psicólogo) e 2 técnicos de nível médio. Parte desses salários pode ser paga com recursos federais.',
        paragraphs: [
          {
            id: 'art6e-pu',
            number: 'Parágrafo único',
            text: 'A formação das equipes de referência deverá considerar o número de famílias e indivíduos referenciados, os tipos e modalidades de atendimento e as aquisições que devem ser garantidas aos usuários, conforme deliberações do CNAS.',
            concept: 'O DIMENSIONAMENTO DAS EQUIPES deve ser proporcional à demanda: quanto mais famílias referenciadas, maior a equipe necessária. O CNAS define parâmetros nacionais.',
            example: 'EXEMPLO: Um CRAS que atende 5.000 famílias precisa de equipe maior do que um que atende 2.500. A NOB-RH/SUAS define a equipe mínima para cada porte de CRAS.',
          }
        ]
      },
      {
        id: 'art6f',
        number: '6º-F',
        title: 'Cadastro Único (CadÚnico)',
        text: 'Fica instituído o Cadastro Único para Programas Sociais do Governo Federal (CadÚnico), registro público eletrônico com a finalidade de coletar, processar, sistematizar e disseminar informações georreferenciadas para a identificação e a caracterização socioeconômica das famílias de baixa renda.',
        concept: 'O CADASTRO ÚNICO (CadÚnico) é o principal instrumento de identificação das famílias de baixa renda no Brasil. É porta de entrada para diversos programas sociais (Bolsa Família/Auxílio Brasil, Tarifa Social de Energia, BPC, habitação, etc.). Contém dados socioeconômicos detalhados das famílias.',
        example: 'EXEMPLO: Maria vai ao CRAS e faz sua inscrição no CadÚnico. A partir desse cadastro, ela é automaticamente avaliada para: Bolsa Família, Tarifa Social de Energia Elétrica, isenção em concursos públicos, ID Jovem, entre outros benefícios que usam o CadÚnico como base.',
      }
    ]
  },
  {
    id: 'cap4',
    number: 'IV',
    title: 'Dos Benefícios, dos Serviços, dos Programas e dos Projetos de Assistência Social',
    sections: [
      {
        id: 'sec-bpc',
        title: 'Seção I - Do Benefício de Prestação Continuada',
        articles: [
          {
            id: 'art20',
            number: '20',
            title: 'Benefício de Prestação Continuada (BPC)',
            text: 'O benefício de prestação continuada é a garantia de um salário-mínimo mensal à pessoa com deficiência e ao idoso com 65 (sessenta e cinco) anos ou mais que comprovem não possuir meios de prover a própria manutenção nem de tê-la provida por sua família.',
            concept: 'O BPC é o principal benefício assistencial brasileiro. Garante 1 SALÁRIO MÍNIMO MENSAL a: (1) IDOSOS com 65 anos ou mais; (2) PESSOAS COM DEFICIÊNCIA de qualquer idade. Em ambos os casos, a renda familiar per capita deve ser igual ou inferior a 1/4 do salário mínimo (ou 1/2 em casos específicos). O BPC é INTRANSFERÍVEL, não gera pensão por morte e não paga 13º.',
            example: 'EXEMPLO: José, 67 anos, mora sozinho e não tem renda. Ele pode requerer o BPC-Idoso no INSS. Se aprovado, receberá 1 salário mínimo por mês até seu falecimento (desde que mantenha os requisitos). Ana, 30 anos, tem deficiência intelectual severa e a família tem renda per capita de R$ 200,00. Ana pode requerer o BPC-PcD.',
            paragraphs: [
              {
                id: 'art20-p1',
                number: '§ 1º',
                text: 'Para os efeitos do disposto no caput, a família é composta pelo requerente, o cônjuge ou companheiro, os pais e, na ausência de um deles, a madrasta ou o padrasto, os irmãos solteiros, os filhos e enteados solteiros e os menores tutelados, desde que vivam sob o mesmo teto.',
                concept: 'Define a COMPOSIÇÃO FAMILIAR para fins de cálculo da renda per capita do BPC. Inclui apenas quem mora junto (mesmo teto) e está nas categorias listadas. Não inclui avós, tios, primos, genros/noras, etc.',
                example: 'EXEMPLO: João (requerente) mora com a esposa, 1 filho solteiro e 1 filho casado. Para o BPC, conta-se: João, esposa e filho solteiro (3 pessoas). O filho casado não entra no cálculo, pois filhos casados são excluídos.',
              },
              {
                id: 'art20-p2',
                number: '§ 2º',
                text: 'Para efeito de concessão do benefício de prestação continuada, considera-se pessoa com deficiência aquela que tem impedimento de longo prazo de natureza física, mental, intelectual ou sensorial, o qual, em interação com uma ou mais barreiras, pode obstruir sua participação plena e efetiva na sociedade em igualdade de condições com as demais pessoas.',
                concept: 'Define PESSOA COM DEFICIÊNCIA para fins de BPC, adotando o modelo biopsicossocial da Convenção da ONU. Não basta ter uma doença ou limitação - é preciso que haja impedimento de LONGO PRAZO (mínimo 2 anos) que, em interação com BARREIRAS sociais, limite a participação.',
                example: 'EXEMPLO: Uma pessoa com paraplegia (impedimento físico de longo prazo) que encontra barreiras de acessibilidade para trabalhar e participar socialmente pode ter direito ao BPC. Já uma pessoa com perna quebrada (não é longo prazo) não se enquadra.',
              },
              {
                id: 'art20-p3',
                number: '§ 3º',
                text: 'Considera-se incapaz de prover a manutenção da pessoa com deficiência ou idosa a família cuja renda mensal per capita seja igual ou inferior a 1/4 (um quarto) do salário-mínimo.',
                concept: 'O critério de RENDA para o BPC é: renda familiar per capita igual ou inferior a 1/4 do salário mínimo. Este critério pode ser flexibilizado pelo juiz considerando outros fatores (gastos com saúde, moradia, etc.).',
                example: 'EXEMPLO: Família de 4 pessoas com renda total de R$ 1.200,00. Renda per capita = R$ 300,00. Se o salário mínimo é R$ 1.412,00, 1/4 = R$ 353,00. Como R$ 300 < R$ 353, a família atende ao critério de renda.',
              },
              {
                id: 'art20-p14',
                number: '§ 14',
                text: 'O benefício de prestação continuada ou o auxílio-inclusão será suspenso pelo órgão concedente quando a pessoa com deficiência exercer atividade remunerada, inclusive na condição de microempreendedor individual, mediante comprovação da relação trabalhista ou da atividade empreendedora.',
                concept: 'O BPC é SUSPENSO (não cancelado) quando a pessoa com deficiência passa a trabalhar. A suspensão permite retorno facilitado ao benefício se perder o emprego em até 2 anos.',
                example: 'EXEMPLO: Pedro recebe BPC-PcD e consegue emprego com carteira assinada. O BPC é suspenso. Se Pedro for demitido dentro de 2 anos, pode solicitar a reativação do BPC sem nova perícia, apenas comprovando a demissão.',
              }
            ]
          },
          {
            id: 'art21',
            number: '21',
            title: 'Requisitos e Procedimentos do BPC',
            text: 'O benefício de prestação continuada deve ser revisto a cada 2 (dois) anos para avaliação da continuidade das condições que lhe deram origem.',
            concept: 'O BPC passa por REVISÃO PERIÓDICA a cada 2 anos. O INSS verifica se os requisitos (renda, deficiência/idade) continuam sendo atendidos. Se houver alteração, o benefício pode ser cessado.',
            example: 'EXEMPLO: Maria recebe BPC-Idosa. A cada 2 anos, o INSS cruza dados para verificar se sua renda familiar continua dentro do limite. Se descobrir que ela passou a receber aposentadoria de valor superior, o BPC será cessado.',
            paragraphs: [
              {
                id: 'art21-p1',
                number: '§ 1º',
                text: 'O pagamento do benefício cessa no momento em que forem superadas as condições referidas no caput, ou em caso de morte do beneficiário.',
                concept: 'O BPC CESSA quando: (1) as condições que geraram o direito são superadas (ex: renda aumentou); (2) morte do beneficiário. NÃO gera pensão por morte - é intransferível.',
                example: 'EXEMPLO: José recebia BPC-Idoso. Com seu falecimento, o benefício cessa automaticamente. Sua esposa não tem direito à pensão do BPC (diferente de aposentadoria). Ela deverá requerer benefício próprio se atender aos requisitos.',
              },
              {
                id: 'art21-p4',
                number: '§ 4º',
                text: 'O benefício de prestação continuada será devido a mais de um membro da mesma família enquanto atendidos os requisitos exigidos nesta Lei.',
                concept: 'Uma mesma família pode ter MAIS DE UM beneficiário do BPC, desde que cada um atenda individualmente aos requisitos.',
                example: 'EXEMPLO: Família com pai idoso de 70 anos e filho com deficiência. Se a renda per capita permitir, AMBOS podem receber BPC simultaneamente. O valor de um BPC não entra no cálculo de renda do outro.',
              }
            ]
          },
          {
            id: 'art21a',
            number: '21-A',
            title: 'BPC na Escola',
            text: 'O benefício de prestação continuada será suspenso pelo órgão concedente quando a pessoa com deficiência exercer atividade remunerada, inclusive na condição de microempreendedor individual.',
            concept: 'Regulamenta a interface entre BPC e atividade remunerada, permitindo que a pessoa com deficiência experimente o trabalho formal com segurança de retorno ao benefício.',
            example: 'EXEMPLO: Programa BPC na Escola identifica que criança beneficiária do BPC está fora da escola. A equipe articula matrícula e acompanhamento, garantindo o direito à educação.',
          }
        ]
      },
      {
        id: 'sec-eventuais',
        title: 'Seção II - Dos Benefícios Eventuais',
        articles: [
          {
            id: 'art22',
            number: '22',
            title: 'Benefícios Eventuais',
            text: 'Entendem-se por benefícios eventuais as provisões suplementares e provisórias que integram organicamente as garantias do Suas e são prestadas aos cidadãos e às famílias em virtude de nascimento, morte, situações de vulnerabilidade temporária e de calamidade pública.',
            concept: 'Os BENEFÍCIOS EVENTUAIS são provisões TEMPORÁRIAS para situações específicas: NATALIDADE (nascimento), MORTE (funeral), VULNERABILIDADE TEMPORÁRIA (desastres, desemprego) e CALAMIDADE PÚBLICA. Diferem do BPC por serem pontuais, não continuados.',
            example: 'EXEMPLO: Família perde a casa em enchente. O município concede benefício eventual de vulnerabilidade temporária: cestas básicas, colchões, auxílio-aluguel por 3 meses, até a família se reorganizar.',
            paragraphs: [
              {
                id: 'art22-p1',
                number: '§ 1º',
                text: 'A concessão e o valor dos benefícios de que trata este artigo serão definidos pelos Estados, Distrito Federal e Municípios e previstos nas respectivas leis orçamentárias anuais.',
                concept: 'Os benefícios eventuais são de responsabilidade dos ESTADOS, DF e MUNICÍPIOS. Cada ente define valores e critérios em sua legislação própria. Não há valor fixo nacional.',
                example: 'EXEMPLO: O município X define auxílio-natalidade de R$ 500,00. O município Y define R$ 800,00. Cada um regula conforme sua realidade e capacidade orçamentária.',
              },
              {
                id: 'art22-p2',
                number: '§ 2º',
                text: 'O auxílio por natalidade é destinado às famílias com renda mensal per capita igual ou inferior a 1/4 (um quarto) do salário-mínimo e consiste em parcela única.',
                concept: 'O AUXÍLIO-NATALIDADE é pago em PARCELA ÚNICA às famílias de baixa renda por ocasião do nascimento de filho. Critério de renda: até 1/4 do salário mínimo per capita.',
                example: 'EXEMPLO: Família com renda per capita de R$ 300 tem um bebê. Pode solicitar o auxílio-natalidade no CRAS, recebendo valor definido pelo município para ajudar nos gastos iniciais com o recém-nascido.',
              },
              {
                id: 'art22-p3',
                number: '§ 3º',
                text: 'O auxílio por morte é destinado às famílias com renda mensal per capita igual ou inferior a 1/4 (um quarto) do salário-mínimo para custear as despesas de urna funerária, velório e sepultamento.',
                concept: 'O AUXÍLIO-FUNERAL cobre despesas com morte de membro da família de baixa renda: urna, velório e sepultamento. Evita que famílias pobres tenham que se endividar para enterrar seus entes.',
                example: 'EXEMPLO: Pai de família de baixa renda falece. A família não tem recursos para o funeral. O município concede auxílio-funeral que cobre os custos com urna, velório e sepultamento digno.',
              }
            ]
          }
        ]
      },
      {
        id: 'sec-servicos',
        title: 'Seção III - Dos Serviços',
        articles: [
          {
            id: 'art23',
            number: '23',
            title: 'Serviços Socioassistenciais',
            text: 'Entendem-se por serviços socioassistenciais as atividades continuadas que visem à melhoria de vida da população e cujas ações, voltadas para as necessidades básicas, observem os objetivos, princípios e diretrizes estabelecidos nesta Lei.',
            concept: 'Os SERVIÇOS SOCIOASSISTENCIAIS são atividades CONTINUADAS (não pontuais) que compõem a rede do SUAS. Incluem: PAIF, PAEFI, Serviços de Convivência, Acolhimento Institucional, entre outros. São tipificados nacionalmente pela Resolução CNAS 109/2009.',
            example: 'EXEMPLO: O PAIF (Serviço de Proteção e Atendimento Integral à Família) é o principal serviço do CRAS. Oferece acolhida, acompanhamento familiar, encaminhamentos e ações comunitárias de forma continuada ao longo do ano.',
            paragraphs: [
              {
                id: 'art23-p1',
                number: '§ 1º',
                text: 'O regulamento instituirá os serviços socioassistenciais.',
                concept: 'Os serviços são regulamentados por normas infralegais, principalmente pela TIPIFICAÇÃO NACIONAL DE SERVIÇOS SOCIOASSISTENCIAIS (Resolução CNAS 109/2009).',
                example: 'EXEMPLO: A Tipificação Nacional define 13 serviços socioassistenciais: PAIF, PAEFI, Serviço de Convivência, Acolhimento Institucional, República, entre outros, cada um com objetivos, usuários e provisões específicas.',
              },
              {
                id: 'art23-p2',
                number: '§ 2º',
                text: 'Na organização dos serviços da assistência social serão criados programas de amparo, entre outros: I - às crianças e adolescentes em situação de risco pessoal e social; II - às pessoas que vivem em situação de rua.',
                concept: 'Destaca dois públicos prioritários que demandam serviços específicos: (1) CRIANÇAS E ADOLESCENTES em risco; (2) POPULAÇÃO EM SITUAÇÃO DE RUA.',
                example: 'EXEMPLO: O Serviço Especializado em Abordagem Social vai às ruas identificar pessoas em situação de rua, oferecendo acolhida e encaminhamento para a rede de proteção.',
              }
            ]
          }
        ]
      },
      {
        id: 'sec-programas',
        title: 'Seção IV - Dos Programas de Assistência Social',
        articles: [
          {
            id: 'art24',
            number: '24',
            title: 'Programas de Assistência Social',
            text: 'Os programas de assistência social compreendem ações integradas e complementares com objetivos, tempo e área de abrangência definidos para qualificar, incentivar e melhorar os benefícios e os serviços assistenciais.',
            concept: 'Os PROGRAMAS são ações com OBJETIVOS, TEMPO e ÁREA DE ABRANGÊNCIA definidos. Diferem dos serviços (continuados) por terem prazo. Complementam benefícios e serviços. Exemplos: Programa de Erradicação do Trabalho Infantil (PETI), Programa de Atenção Integral à Família.',
            example: 'EXEMPLO: O PETI (Programa de Erradicação do Trabalho Infantil) é um programa que articula transferência de renda, serviços de convivência e acompanhamento familiar para retirar crianças e adolescentes do trabalho infantil.',
            paragraphs: [
              {
                id: 'art24-p1',
                number: '§ 1º',
                text: 'Os programas de que trata este artigo serão definidos pelos respectivos Conselhos de Assistência Social, obedecidos os objetivos e princípios que regem esta lei, com prioridade para a inserção profissional e social.',
                concept: 'Os programas devem ser definidos com participação dos CONSELHOS DE ASSISTÊNCIA SOCIAL, garantindo controle social. A INSERÇÃO PROFISSIONAL E SOCIAL é prioridade.',
                example: 'EXEMPLO: O CMAS delibera sobre a criação de programa municipal de capacitação profissional para jovens em vulnerabilidade, articulando assistência social e trabalho.',
              }
            ]
          },
          {
            id: 'art24a',
            number: '24-A',
            title: 'Programas de Transferência de Renda',
            text: 'Fica instituído o Serviço de Proteção e Atendimento Integral à Família (Paif), que integra a proteção social básica e consiste na oferta de ações e serviços socioassistenciais de prestação continuada.',
            concept: 'O PAIF é o principal serviço da proteção social básica, executado obrigatoriamente pelo CRAS. Oferece acompanhamento familiar, fortalecimento de vínculos e acesso a direitos de forma continuada.',
            example: 'EXEMPLO: Família inscrita no CadÚnico passa a ser acompanhada pelo PAIF. A equipe realiza visitas domiciliares, participa de reuniões de grupo, recebe orientações sobre direitos e é apoiada em suas demandas.',
          },
          {
            id: 'art24c',
            number: '24-C',
            title: 'Programas de Transferência de Renda',
            text: 'Ficam instituídos os seguintes programas de transferência de renda: I - Programa Bolsa Família; II - outros que venham a ser criados pelo Poder Executivo.',
            concept: 'Institucionaliza os PROGRAMAS DE TRANSFERÊNCIA DE RENDA como parte da política de assistência social. O Bolsa Família (atual Auxílio Brasil) é o principal exemplo, combinando transferência monetária com condicionalidades em saúde e educação.',
            example: 'EXEMPLO: Família com renda per capita de R$ 200 é incluída no Bolsa Família. Recebe benefício mensal e se compromete a manter crianças na escola e em dia com vacinas (condicionalidades).',
          }
        ]
      },
      {
        id: 'sec-projetos',
        title: 'Seção V - Dos Projetos de Enfrentamento da Pobreza',
        articles: [
          {
            id: 'art25',
            number: '25',
            title: 'Projetos de Enfrentamento da Pobreza',
            text: 'Os projetos de enfrentamento da pobreza compreendem a instituição de investimento econômico-social nos grupos populares, buscando subsidiar, financeira e tecnicamente, iniciativas que lhes garantam meios, capacidade produtiva e de gestão para melhoria das condições gerais de subsistência.',
            concept: 'Os PROJETOS de enfrentamento da pobreza são ações de INVESTIMENTO ECONÔMICO-SOCIAL voltadas à geração de renda e autonomia. Incluem: capacitação profissional, apoio a empreendimentos solidários, microcrédito produtivo. Têm caráter emancipatório.',
            example: 'EXEMPLO: Projeto de apoio a mulheres em vulnerabilidade para criação de cooperativa de costura: oferece capacitação, máquinas, apoio de gestão e comercialização, visando autonomia econômica do grupo.',
            paragraphs: [
              {
                id: 'art25-pu',
                number: 'Parágrafo único',
                text: 'Os projetos de que trata este artigo serão subsidiados pelo Sistema Único de Assistência Social (Suas) e terão como objetivo a concessão de oportunidades e meios para a capacitação laboral e a reinserção de pessoas com deficiência e de suas famílias no mercado de trabalho.',
                concept: 'Destaca que os projetos devem incluir ações específicas para PESSOAS COM DEFICIÊNCIA, promovendo sua capacitação e inserção no mercado de trabalho.',
                example: 'EXEMPLO: Projeto de qualificação profissional para jovens com deficiência intelectual, preparando-os para vagas em empresas que cumprem cotas da Lei de Cotas (Lei 8.213/91).',
              }
            ]
          },
          {
            id: 'art26',
            number: '26',
            title: 'Estímulo a Projetos',
            text: 'O incentivo a projetos de enfrentamento da pobreza assentar-se-á em mecanismos de articulação e de participação de diferentes áreas governamentais e em sistema de cooperação entre organismos governamentais, não governamentais e da sociedade civil.',
            concept: 'Os projetos de enfrentamento da pobreza devem ser INTERSETORIAIS (articulando diferentes áreas do governo) e PARTICIPATIVOS (envolvendo sociedade civil e entidades). Não são ações isoladas da assistência social.',
            example: 'EXEMPLO: Projeto de inclusão produtiva articula: Assistência Social (identificação das famílias), Trabalho (qualificação), Desenvolvimento Econômico (apoio a empreendimentos), ONGs (execução de cursos), Sistema S (certificação).',
          }
        ]
      },
      {
        id: 'sec-auxilio',
        title: 'Seção VI - Do Auxílio-Inclusão',
        articles: [
          {
            id: 'art26a',
            number: '26-A',
            title: 'Auxílio-Inclusão',
            text: 'O auxílio-inclusão será devido à pessoa com deficiência moderada ou grave que: I - receba o benefício de prestação continuada e passe a exercer atividade remunerada; II - tenha recebido o BPC nos 5 anos anteriores ao início da atividade remunerada; III - exerça atividade remunerada que a enquadre como segurada obrigatória do RGPS; IV - tenha inscrita no CadÚnico; V - tenha renda familiar per capita igual ou inferior a 2 salários-mínimos.',
            concept: 'O AUXÍLIO-INCLUSÃO foi criado para incentivar a pessoa com deficiência beneficiária do BPC a ingressar no mercado de trabalho. É um benefício no valor de 50% do salário mínimo pago a quem deixa o BPC para trabalhar, garantindo complementação de renda e segurança na transição.',
            example: 'EXEMPLO: Ana recebia BPC-PcD de R$ 1.412,00. Conseguiu emprego com salário de R$ 1.800,00. Ao começar a trabalhar, o BPC é suspenso, mas ela passa a receber o Auxílio-Inclusão de R$ 706,00 (50% do SM), totalizando R$ 2.506,00 de renda. Isso incentiva a busca por trabalho formal.',
            paragraphs: [
              {
                id: 'art26a-p1',
                number: '§ 1º',
                text: 'O auxílio-inclusão será pago pelo INSS e corresponderá ao valor de 50% (cinquenta por cento) do benefício de prestação continuada.',
                concept: 'O valor do AUXÍLIO-INCLUSÃO é 50% do BPC (meio salário mínimo). É operacionalizado pelo INSS, assim como o BPC.',
                example: 'EXEMPLO: Com salário mínimo de R$ 1.412,00, o BPC é R$ 1.412,00 e o auxílio-inclusão é R$ 706,00.',
              },
              {
                id: 'art26a-p2',
                number: '§ 2º',
                text: 'O recebimento do auxílio-inclusão está condicionado à suspensão do BPC.',
                concept: 'Não é possível receber BPC e auxílio-inclusão simultaneamente. Ao iniciar trabalho formal, o BPC é SUSPENSO e o auxílio-inclusão é concedido.',
                example: 'EXEMPLO: No mês em que começa a trabalhar, a pessoa deixa de receber o BPC e passa a receber o auxílio-inclusão, que continua enquanto mantiver o vínculo empregatício.',
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'cap5',
    number: 'V',
    title: 'Do Financiamento da Assistência Social',
    articles: [
      {
        id: 'art27',
        number: '27',
        title: 'Fundo Nacional de Assistência Social (FNAS)',
        text: 'Fica o Fundo Nacional de Ação Comunitária (Funac), instituído pelo Decreto nº 91.970, de 22 de novembro de 1985, transformado no Fundo Nacional de Assistência Social (FNAS).',
        concept: 'O FNAS - Fundo Nacional de Assistência Social - é o instrumento de gestão financeira dos recursos federais da assistência social. Todo recurso federal para assistência social deve passar pelo FNAS. Há também FEAS (estadual) e FMAS (municipal).',
        example: 'EXEMPLO: A União repassa recursos do FNAS para os FMAS dos municípios, que utilizam para manter CRAS, CREAS, serviços de acolhimento e pagar benefícios eventuais.',
      },
      {
        id: 'art28',
        number: '28',
        title: 'Fontes de Financiamento',
        text: 'O financiamento dos benefícios, serviços, programas e projetos estabelecidos nesta lei far-se-á com os recursos da União, dos Estados, do Distrito Federal e dos Municípios, das demais contribuições sociais previstas no art. 195 da Constituição Federal, além daqueles que compõem o Fundo Nacional de Assistência Social (FNAS).',
        concept: 'O financiamento do SUAS é TRIPARTITE: União, Estados e Municípios contribuem (COFINANCIAMENTO). As fontes incluem recursos orçamentários dos três entes e contribuições sociais previstas na Constituição (que financiam a Seguridade Social).',
        example: 'EXEMPLO: O custeio de um CRAS é cofinanciado: a União repassa recurso via FNAS, o Estado complementa via FEAS, e o município coloca contrapartida própria via FMAS. Os três entes contribuem.',
        paragraphs: [
          {
            id: 'art28-p1',
            number: '§ 1º',
            text: 'Cabe ao órgão da Administração Pública responsável pela coordenação da Política de Assistência Social nas 3 (três) esferas de governo gerir o Fundo de Assistência Social, sob orientação e controle dos respectivos Conselhos de Assistência Social.',
            concept: 'Cada ente federativo tem seu ÓRGÃO GESTOR (Ministério/Secretaria) que administra o respectivo Fundo (FNAS/FEAS/FMAS), sob controle do Conselho (CNAS/CEAS/CMAS).',
            example: 'EXEMPLO: A Secretaria Municipal de Assistência Social gere o FMAS, mas o Conselho Municipal (CMAS) orienta e controla a aplicação dos recursos, aprovando o plano de aplicação.',
          },
          {
            id: 'art28-p3',
            number: '§ 3º',
            text: 'O financiamento da assistência social no Suas deve ser efetuado mediante cofinanciamento dos 3 (três) entes federados, devendo os recursos alocados nos fundos de assistência social ser voltados à operacionalização, prestação, aprimoramento e viabilização dos serviços, programas, projetos e benefícios desta política.',
            concept: 'O COFINANCIAMENTO é obrigatório: os três entes devem contribuir. Os recursos devem ser usados exclusivamente para ações da política de assistência social.',
            example: 'EXEMPLO: Município não pode usar recurso do FMAS para outras finalidades (pavimentação, saúde, etc.). Recurso de assistência social é para assistência social.',
          }
        ]
      },
      {
        id: 'art30',
        number: '30',
        title: 'Condições para Repasses',
        text: 'É condição para os repasses, aos Municípios, aos Estados e ao Distrito Federal, dos recursos de que trata esta lei, a efetiva instituição e funcionamento de: I - Conselho de Assistência Social, de composição paritária entre governo e sociedade civil; II - Fundo de Assistência Social, com orientação e controle dos respectivos Conselhos de Assistência Social; III - Plano de Assistência Social.',
        concept: 'Para receber recursos federais, Estados e Municípios devem ter o "CPF" da assistência social: CONSELHO (paritário), PLANO (planejamento) e FUNDO (gestão financeira). Sem estes três instrumentos, não há repasse.',
        example: 'EXEMPLO: Município que não tem CMAS constituído ou não aprovou seu Plano Municipal não pode receber recursos do FNAS. Precisa regularizar a situação para habilitar-se aos repasses.',
        paragraphs: [
          {
            id: 'art30-pu',
            number: 'Parágrafo único',
            text: 'É, ainda, condição para transferência de recursos do FNAS aos Estados, ao Distrito Federal e aos Municípios a comprovação orçamentária dos recursos próprios destinados à Assistência Social, alocados em seus respectivos Fundos de Assistência Social.',
            concept: 'Além do CPF, o ente deve comprovar CONTRAPARTIDA: recursos próprios alocados no Fundo. Não basta ter o fundo criado, precisa ter recursos do tesouro local nele.',
            example: 'EXEMPLO: O município deve demonstrar que alocou em seu orçamento recursos próprios no FMAS. Se só houver recurso federal repassado, sem contrapartida local, pode haver irregularidade.',
          }
        ]
      },
      {
        id: 'art30a',
        number: '30-A',
        title: 'Transferências Automáticas',
        text: 'O cofinanciamento dos serviços, programas, projetos e benefícios eventuais, no que couber, e o aprimoramento da gestão da política de assistência social no Suas se efetuam por meio de transferências automáticas entre os fundos de assistência social e mediante alocação de recursos próprios nesses fundos nas 3 (três) esferas de governo.',
        concept: 'As TRANSFERÊNCIAS são AUTOMÁTICAS (fundo a fundo), sem necessidade de convênio para cada repasse. Isso agiliza e desburocratiza o financiamento do SUAS.',
        example: 'EXEMPLO: Todo mês, o FNAS repassa automaticamente para o FMAS o valor de cofinanciamento federal do PAIF. O município recebe direto na conta do fundo, sem precisar firmar convênio específico.',
      }
    ]
  },
  {
    id: 'cap6',
    number: 'VI',
    title: 'Das Disposições Gerais e Transitórias',
    articles: [
      {
        id: 'art31',
        number: '31',
        title: 'Papel do Ministério Público',
        text: 'Cabe ao Ministério Público zelar pelo efetivo respeito aos direitos estabelecidos nesta lei.',
        concept: 'O MINISTÉRIO PÚBLICO é o fiscal da lei, devendo zelar pelo cumprimento da LOAS. Pode instaurar inquéritos, ajuizar ações civis públicas e atuar na defesa dos direitos socioassistenciais.',
        example: 'EXEMPLO: Se um município não implementa CRAS em área vulnerável, o MP pode notificar o gestor, instaurar inquérito civil e, se necessário, ajuizar ação civil pública para obrigar a implantação do serviço.',
      },
      {
        id: 'art36',
        number: '36',
        title: 'Sanções a Entidades',
        text: 'As entidades e organizações de assistência social que incorrerem em irregularidades na aplicação dos recursos que lhes foram repassados pelos poderes públicos terão a sua vinculação ao Suas cancelada, sem prejuízo de responsabilidade civil e penal.',
        concept: 'Entidades que cometerem IRREGULARIDADES na aplicação de recursos públicos perdem a vinculação ao SUAS (não podem mais receber recursos), além de responderem civil e penalmente.',
        example: 'EXEMPLO: ONG que recebeu recurso para serviço de convivência e desviou parte do valor terá: (1) vinculação ao SUAS cancelada; (2) obrigação de devolver recursos; (3) possível processo criminal contra responsáveis.',
      },
      {
        id: 'art37',
        number: '37',
        title: 'Prazo para Pagamento do BPC',
        text: 'O benefício de prestação continuada será devido após o cumprimento, pelo requerente, de todos os requisitos legais e regulamentares exigidos para a sua concessão, inclusive apresentação da documentação necessária, devendo o seu pagamento ser efetuado em até quarenta e cinco dias após cumpridas as exigências.',
        concept: 'O INSS tem prazo de 45 DIAS para pagar o BPC após o cumprimento de todos os requisitos. Se atrasar, deve atualizar o valor pelo mesmo critério dos benefícios previdenciários.',
        example: 'EXEMPLO: Maria requereu BPC em 01/03, foi aprovado em 15/03 após perícia. O INSS tem até 30/04 (45 dias) para efetuar o primeiro pagamento. Se pagar só em 15/05, deve corrigir monetariamente os valores em atraso.',
      },
      {
        id: 'art40',
        number: '40',
        title: 'Extinção de Benefícios Anteriores',
        text: 'Com a implantação dos benefícios previstos nos arts. 20 e 22 desta lei, extinguem-se a renda mensal vitalícia, o auxílio-natalidade e o auxílio-funeral existentes no âmbito da Previdência Social.',
        concept: 'A LOAS extinguiu benefícios assistenciais que antes eram pagos pela Previdência: Renda Mensal Vitalícia (substituída pelo BPC), auxílio-natalidade e auxílio-funeral previdenciários (substituídos pelos benefícios eventuais). A assistência social passou a ter seus próprios instrumentos.',
        example: 'EXEMPLO: Antes da LOAS, idosos carentes recebiam a Renda Mensal Vitalícia pelo INSS. Após 1993, esse benefício foi substituído pelo BPC, que mantém gestão pelo INSS mas com natureza assistencial, não previdenciária.',
      },
      {
        id: 'art40a',
        number: '40-A',
        title: 'Pagamento Preferencial à Mulher',
        text: 'Os benefícios monetários decorrentes do disposto nos arts. 22, 24-C e 25 desta Lei serão pagos preferencialmente à mulher responsável pela unidade familiar, quando cabível.',
        concept: 'Os benefícios devem ser pagos PREFERENCIALMENTE À MULHER responsável pela família, reconhecendo seu papel central na gestão doméstica e potencializando o impacto dos recursos na família.',
        example: 'EXEMPLO: O Bolsa Família é pago preferencialmente à mãe ou mulher responsável pelo domicílio. Pesquisas mostram que mulheres tendem a investir mais em alimentação, saúde e educação dos filhos.',
      },
      {
        id: 'art40b',
        number: '40-B',
        title: 'Avaliação da Deficiência para BPC',
        text: 'Enquanto não estiver regulamentado o instrumento de avaliação de que tratam os §§ 1º e 2º do art. 2º da Lei nº 13.146, de 6 de julho de 2015 (Estatuto da Pessoa com Deficiência), a concessão do benefício de prestação continuada à pessoa com deficiência ficará sujeita à avaliação do grau da deficiência e do impedimento, composta por avaliação médica e avaliação social realizadas pelo INSS.',
        concept: 'A avaliação para BPC-PcD é BIOPSICOSSOCIAL, composta por: (1) AVALIAÇÃO MÉDICA (perícia médica federal) que analisa o impedimento físico, mental, intelectual ou sensorial; (2) AVALIAÇÃO SOCIAL (serviço social do INSS) que analisa as barreiras e o contexto social. Ambas são necessárias.',
        example: 'EXEMPLO: João requer BPC-PcD. Passa por perícia médica (que atesta tetraplegia) e avaliação social (que identifica barreiras de acessibilidade, ausência de suporte familiar, impossibilidade de trabalho). A combinação das duas avaliações define o direito.',
      }
    ]
  },
  {
    id: 'cap-conselhos',
    number: 'III-A',
    title: 'Das Instâncias Deliberativas do SUAS',
    articles: [
      {
        id: 'art16',
        number: '16',
        title: 'Instâncias Deliberativas',
        text: 'As instâncias deliberativas do Suas, de caráter permanente e composição paritária entre governo e sociedade civil, são: I - o Conselho Nacional de Assistência Social; II - os Conselhos Estaduais de Assistência Social; III - o Conselho de Assistência Social do Distrito Federal; IV - os Conselhos Municipais de Assistência Social.',
        concept: 'As INSTÂNCIAS DELIBERATIVAS são os espaços de participação e controle social do SUAS. São PERMANENTES (funcionam continuamente) e PARITÁRIAS (50% governo, 50% sociedade civil). Existem em todas as esferas federativas: CNAS (nacional), CEAS (estadual), CAS-DF (Distrito Federal) e CMAS (municipal). São órgãos colegiados que deliberam sobre a política de assistência social.',
        example: 'EXEMPLO: O CMAS de um município é composto por 12 membros: 6 representantes do governo (secretarias, prefeito) e 6 da sociedade civil (entidades de assistência social, usuários, trabalhadores). Juntos deliberam sobre o plano municipal, aprovam contas do fundo, fiscalizam serviços.',
        items: [
          {
            id: 'art16-i',
            letter: 'I',
            text: 'o Conselho Nacional de Assistência Social',
            concept: 'O CNAS é a instância máxima de deliberação da política de assistência social no âmbito federal. Aprova a Política Nacional, normatiza o SUAS, certifica entidades beneficentes.',
            example: 'EXEMPLO: O CNAS aprovou a Tipificação Nacional de Serviços Socioassistenciais (Resolução 109/2009), que define todos os serviços do SUAS em âmbito nacional.',
          },
          {
            id: 'art16-ii',
            letter: 'II',
            text: 'os Conselhos Estaduais de Assistência Social',
            concept: 'Os CEAS deliberam sobre a política estadual, aprovam o plano estadual, fiscalizam o FEAS e apoiam tecnicamente os municípios.',
            example: 'EXEMPLO: O CEAS de São Paulo aprova o Plano Estadual de Assistência Social e delibera sobre a aplicação dos recursos do FEAS.',
          },
          {
            id: 'art16-iii',
            letter: 'III',
            text: 'o Conselho de Assistência Social do Distrito Federal',
            concept: 'O CAS-DF tem competências tanto estaduais quanto municipais, dada a natureza híbrida do Distrito Federal.',
            example: 'EXEMPLO: O CAS-DF delibera sobre toda a política de assistência social do DF, fiscalizando tanto serviços de âmbito regional quanto local.',
          },
          {
            id: 'art16-iv',
            letter: 'IV',
            text: 'os Conselhos Municipais de Assistência Social',
            concept: 'Os CMAS são as instâncias deliberativas mais próximas do cidadão. Aprovam o plano municipal, fiscalizam serviços e entidades, orientam o FMAS, inscrevem entidades de assistência social.',
            example: 'EXEMPLO: O CMAS de Belo Horizonte inscreve entidades de assistência social, aprova o Plano Municipal, fiscaliza CRAS e CREAS e aprova a prestação de contas do FMAS.',
          }
        ]
      },
      {
        id: 'art17',
        number: '17',
        title: 'Conselho Nacional de Assistência Social - CNAS',
        text: 'Fica instituído o Conselho Nacional de Assistência Social (CNAS), órgão superior de deliberação colegiada, vinculado à estrutura do órgão da Administração Pública Federal responsável pela coordenação da Política Nacional de Assistência Social.',
        concept: 'O CNAS é o órgão superior de deliberação do SUAS em nível federal. Está vinculado ao Ministério responsável pela assistência social. É composto por 18 membros titulares (9 governamentais e 9 da sociedade civil), com mandato de 2 anos, permitida uma recondução.',
        example: 'EXEMPLO: O CNAS se reúne mensalmente em Brasília para deliberar sobre normas do SUAS, como a NOB-SUAS (Norma Operacional Básica), aprovar o plano nacional e fiscalizar a execução da política em âmbito federal.',
        paragraphs: [
          {
            id: 'art17-p1',
            number: '§ 1º',
            text: 'O CNAS é composto por 18 (dezoito) membros e respectivos suplentes, cujos nomes serão indicados ao órgão da Administração Pública Federal responsável pela coordenação da Política Nacional de Assistência Social, de acordo com os seguintes critérios: I - 9 (nove) representantes governamentais, incluindo 1 (um) representante dos Estados e 1 (um) dos Municípios; II - 9 (nove) representantes da sociedade civil.',
            concept: 'A COMPOSIÇÃO PARITÁRIA garante equilíbrio de poder entre governo e sociedade civil. Os 9 representantes governamentais incluem: representantes de ministérios relacionados, 1 dos Estados (indicado pelo FONSEAS) e 1 dos Municípios (indicado pelo CONGEMAS). Os 9 da sociedade civil são eleitos em assembleia.',
            example: 'EXEMPLO: Na composição do CNAS, o governo é representado por membros dos Ministérios da área social, além de 1 secretário estadual (FONSEAS) e 1 secretário municipal (CONGEMAS). A sociedade civil elege representantes de entidades de assistência social, trabalhadores do SUAS e usuários.',
          },
          {
            id: 'art17-p4',
            number: '§ 4º',
            text: 'Os representantes da sociedade civil serão eleitos em foro próprio, sob fiscalização do Ministério Público Federal.',
            concept: 'A ELEIÇÃO dos representantes da sociedade civil ocorre em assembleia/foro específico, garantindo a legitimidade democrática da representação. O MPF fiscaliza para assegurar a lisura do processo.',
            example: 'EXEMPLO: A cada 2 anos, realiza-se assembleia nacional para eleição dos representantes da sociedade civil no CNAS. Entidades de assistência social, organizações de trabalhadores e de usuários inscrevem candidaturas e votam, sob fiscalização do MPF.',
          }
        ]
      },
      {
        id: 'art18',
        number: '18',
        title: 'Competências do CNAS',
        text: 'Compete ao Conselho Nacional de Assistência Social:',
        concept: 'As COMPETÊNCIAS DO CNAS abrangem: aprovar a Política Nacional, normatizar o SUAS, acompanhar e avaliar a gestão, aprovar proposta orçamentária, estabelecer diretrizes para certificação de entidades, zelar pela efetivação do sistema descentralizado e participativo, entre outras atribuições fundamentais para o funcionamento do SUAS.',
        example: 'EXEMPLO: É competência do CNAS aprovar as resoluções que regulamentam o funcionamento do SUAS, como a Tipificação Nacional de Serviços, NOB-SUAS, NOB-RH/SUAS, critérios de partilha de recursos, entre outras normas fundamentais.',
        items: [
          {
            id: 'art18-i',
            letter: 'I',
            text: 'aprovar a Política Nacional de Assistência Social',
            concept: 'A PNAS (Política Nacional de Assistência Social) é o documento que define diretrizes, objetivos, princípios e organização da política em âmbito nacional. Foi aprovada em 2004 e é base do SUAS.',
            example: 'EXEMPLO: A PNAS 2004 foi aprovada pela Resolução CNAS nº 145/2004, definindo a organização do SUAS e orientando toda a política nacional.',
          },
          {
            id: 'art18-ii',
            letter: 'II',
            text: 'normatizar as ações e regular a prestação de serviços de natureza pública e privada no campo da assistência social',
            concept: 'O CNAS tem PODER NORMATIVO: edita resoluções que regulamentam toda a política de assistência social, vinculando tanto o setor público quanto as entidades privadas.',
            example: 'EXEMPLO: A Resolução CNAS 109/2009 (Tipificação) normatiza os serviços; a Resolução CNAS 33/2012 define critérios para entidades de assistência social.',
          },
          {
            id: 'art18-v',
            letter: 'V',
            text: 'zelar pela efetivação do sistema descentralizado e participativo de assistência social',
            concept: 'O CNAS deve garantir que o SUAS funcione de forma DESCENTRALIZADA (respeitando autonomia dos entes) e PARTICIPATIVA (com controle social efetivo em todas as esferas).',
            example: 'EXEMPLO: O CNAS monitora se estados e municípios estão implementando seus conselhos, fundos e planos, condição para participação no SUAS.',
          },
          {
            id: 'art18-vi',
            letter: 'VI',
            text: 'a partir da realização da II Conferência Nacional de Assistência Social em 1997, convocar ordinariamente, a cada quatro anos, a Conferência Nacional de Assistência Social',
            concept: 'As CONFERÊNCIAS são espaços de participação ampliada, convocadas a cada 4 anos, onde a sociedade avalia a política e propõe diretrizes para o próximo período.',
            example: 'EXEMPLO: A Conferência Nacional de Assistência Social reúne milhares de delegados de todo o país, eleitos nas conferências municipais e estaduais, para avaliar o SUAS e propor diretrizes.',
          }
        ]
      },
      {
        id: 'art19',
        number: '19',
        title: 'Competências do Órgão Gestor Federal',
        text: 'Compete ao órgão da Administração Pública Federal responsável pela coordenação da Política Nacional de Assistência Social:',
        concept: 'Define as COMPETÊNCIAS DO ÓRGÃO GESTOR FEDERAL (Ministério), diferenciando-as das competências do CNAS. O Ministério EXECUTA a política, enquanto o CNAS DELIBERA. O Ministério coordena, financia, monitora, capacita, estabelece padrões e apoia tecnicamente estados e municípios.',
        example: 'EXEMPLO: Cabe ao Ministério (órgão gestor federal): coordenar o SUAS nacionalmente, gerir o FNAS, propor orçamento, estabelecer padrões de qualidade, capacitar gestores, manter sistemas de informação (CadSUAS, CadÚnico), apoiar tecnicamente estados e municípios.',
        items: [
          {
            id: 'art19-i',
            letter: 'I',
            text: 'coordenar e articular as ações no campo da assistência social',
            concept: 'A COORDENAÇÃO NACIONAL garante unidade e coerência à política em todo o território nacional, articulando os três níveis de governo.',
            example: 'EXEMPLO: O Ministério coordena reuniões da CIT (Comissão Intergestores Tripartite), onde União, Estados (FONSEAS) e Municípios (CONGEMAS) pactuam a operacionalização do SUAS.',
          },
          {
            id: 'art19-ix',
            letter: 'IX',
            text: 'formular política para a formação sistemática e continuada de recursos humanos no campo da assistência social',
            concept: 'A CAPACITAÇÃO CONTINUADA dos trabalhadores do SUAS é responsabilidade federal, garantindo qualificação profissional em todo o país.',
            example: 'EXEMPLO: O Ministério desenvolve programas de capacitação como o CapacitaSUAS, oferecendo cursos presenciais e a distância para trabalhadores e gestores do SUAS.',
          },
          {
            id: 'art19-x',
            letter: 'X',
            text: 'elaborar e publicar anualmente relatórios de gestão e de execução orçamentária',
            concept: 'A TRANSPARÊNCIA na gestão exige publicação anual de relatórios, permitindo o controle social e a accountability.',
            example: 'EXEMPLO: O Ministério publica anualmente relatório detalhando: recursos repassados a cada estado/município, número de beneficiários, serviços implantados, metas alcançadas.',
          }
        ]
      },
      {
        id: 'art9',
        number: '9º',
        title: 'Inscrição de Entidades nos Conselhos',
        text: 'O funcionamento das entidades e organizações de assistência social depende de prévia inscrição no respectivo Conselho Municipal de Assistência Social, ou no Conselho de Assistência Social do Distrito Federal, conforme o caso.',
        concept: 'A INSCRIÇÃO no CMAS/CAS-DF é OBRIGATÓRIA para funcionamento de entidades de assistência social. É diferente do registro no CNPJ ou da certificação CEBAS. A inscrição atesta que a entidade atende aos requisitos para atuar na área.',
        example: 'EXEMPLO: Uma ONG que pretende executar serviço de acolhimento para idosos deve primeiro inscrever-se no CMAS do município. Sem essa inscrição, não pode operar como entidade de assistência social nem firmar convênios.',
        paragraphs: [
          {
            id: 'art9-p1',
            number: '§ 1º',
            text: 'A regulamentação desta lei definirá os critérios de inscrição e funcionamento das entidades com atuação em mais de um município no mesmo Estado, ou em mais de um Estado ou Distrito Federal.',
            concept: 'Entidades com atuação em múltiplos municípios ou estados têm regras específicas de inscrição, definidas em regulamento.',
            example: 'EXEMPLO: Uma entidade nacional que atua em vários estados inscreve-se no CNAS; uma estadual com atuação em vários municípios inscreve-se no CEAS.',
          },
          {
            id: 'art9-p2',
            number: '§ 2º',
            text: 'Cabe ao Conselho Municipal de Assistência Social e ao Conselho de Assistência Social do Distrito Federal a fiscalização das entidades referidas no caput na forma prevista em lei ou regulamento.',
            concept: 'Os CMAS e CAS-DF têm PODER FISCALIZATÓRIO sobre as entidades inscritas, podendo verificar o cumprimento das exigências legais.',
            example: 'EXEMPLO: O CMAS pode realizar visitas de fiscalização às entidades inscritas, verificando condições de atendimento, qualificação de pessoal, adequação do serviço às normativas.',
          }
        ]
      }
    ]
  }
];
