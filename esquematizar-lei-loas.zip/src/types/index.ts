export interface Article {
  id: string;
  number: string;
  title: string;
  text: string;
  concept: string;
  example: string;
  paragraphs?: Paragraph[];
  items?: Item[];
  isRevoked?: boolean;
  updatedBy?: string;
}

export interface Paragraph {
  id: string;
  number: string;
  text: string;
  concept?: string;
  example?: string;
  items?: Item[];
}

export interface Item {
  id: string;
  letter: string;
  text: string;
  concept?: string;
  example?: string;
  subItems?: SubItem[];
}

export interface SubItem {
  id: string;
  letter: string;
  text: string;
}

export interface Section {
  id: string;
  title: string;
  articles: Article[];
}

export interface Chapter {
  id: string;
  number: string;
  title: string;
  sections?: Section[];
  articles?: Article[];
}
